package com.c0324.casestudym5.repository;

import com.c0324.casestudym5.model.MultiFile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MultiFileRepository extends JpaRepository<MultiFile, Long> {

}
